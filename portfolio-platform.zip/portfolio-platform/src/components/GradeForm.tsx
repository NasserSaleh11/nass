"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = { submissionId: string; max: number; fixedMax: boolean; grade?: number; feedback?: string; status: string };

export default function GradeForm({ submissionId, max, fixedMax, grade, feedback, status }: Props) {
  const router = useRouter();
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErr("");
    const f = new FormData(e.currentTarget);
    const g = String(f.get("grade") ?? "");
    const res = await fetch("/api/evaluations", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        submissionId, status: f.get("status"),
        grade: g === "" ? undefined : Number(g),
        maxGrade: fixedMax ? undefined : Number(f.get("maxGrade") || 20),
        feedback: String(f.get("feedback") ?? ""),
        internalNote: String(f.get("internalNote") ?? "") || undefined,
      }) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setErr(j.error ?? "تعذّر الحفظ.");
    router.refresh();
  }

  return (
    <details>
      <summary>{grade !== undefined ? "تعديل التقييم" : "تقييم"}</summary>
      <form onSubmit={onSubmit}>
        <div className="row">
          <div><label>الدرجة من {max}</label><input name="grade" type="number" min={0} max={max} step="0.5" defaultValue={grade} /></div>
          {!fixedMax && <div><label>الدرجة العظمى</label><input name="maxGrade" type="number" min={1} defaultValue={max} /></div>}
          <div><label>الحالة</label>
            <select name="status" defaultValue={status === "PENDING" ? "EVALUATED" : status}>
              <option value="EVALUATED">مُقيَّم</option><option value="UNDER_REVIEW">قيد المراجعة</option>
              <option value="RESUBMIT_REQUESTED">طلب إعادة التسليم</option></select></div>
        </div>
        <label>ملاحظات للطالب</label><textarea name="feedback" rows={3} defaultValue={feedback} maxLength={2000} />
        <label>ملاحظة داخلية (لا تظهر للطالب)</label><input name="internalNote" maxLength={2000} />
        <div className="err" role="alert">{err}</div>
        <button className="btn" disabled={busy}>حفظ التقييم</button>
      </form>
    </details>
  );
}
