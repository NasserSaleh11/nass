"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { send } from "@/lib/client";

type Opt = { classId: string; subjectId: string; label: string };
type Item = { id: string; title: string; description: string | null; maxGrade: number; deadline: string | null; isActive: boolean; meta: string };
const iso = (d: string) => new Date(d + "T23:59:00").toISOString();

export default function AssignmentManager({ options, items }: { options: Opt[]; items: Item[] }) {
  const router = useRouter(); const [err, setErr] = useState("");

  async function create(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErr("");
    const form = e.currentTarget, f = new FormData(form), [classId, subjectId] = String(f.get("opt")).split("|");
    const d = String(f.get("deadline") || "");
    const r = await send("/api/assignments", "POST", { title: f.get("title"), description: String(f.get("description") || "") || undefined,
      classId, subjectId, maxGrade: Number(f.get("maxGrade")), deadline: d ? iso(d) : undefined });
    if (!r.ok) return setErr(r.error);
    form.reset(); router.refresh();
  }
  async function edit(id: string, e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErr("");
    const f = new FormData(e.currentTarget), d = String(f.get("deadline") || "");
    const r = await send(`/api/assignments/${id}`, "PATCH", { title: f.get("title"), maxGrade: Number(f.get("maxGrade")),
      deadline: d ? iso(d) : null, isActive: f.get("isActive") === "on" });
    if (!r.ok) return setErr(r.error);
    router.refresh();
  }
  async function del(id: string, title: string) {
    if (!confirm(`حذف «${title}»؟ تبقى تسليمات الطلاب كأعمال غير مرتبطة بواجب.`)) return;
    const r = await send(`/api/assignments/${id}`, "DELETE");
    if (!r.ok) return setErr(r.error);
    router.refresh();
  }

  return (
    <div>
      <form className="card" onSubmit={create}><h3>واجب جديد</h3>
        {options.length === 0 ? <p className="muted">لم يعيّنك المدير على أي فصل ومادة بعد.</p> : (<>
          <label>العنوان</label><input name="title" required minLength={2} maxLength={120} />
          <div className="row">
            <div><label>الفصل والمادة</label><select name="opt">{options.map((o) => <option key={o.classId + o.subjectId} value={`${o.classId}|${o.subjectId}`}>{o.label}</option>)}</select></div>
            <div><label>الدرجة العظمى</label><input name="maxGrade" type="number" min={1} defaultValue={20} required /></div>
            <div><label>آخر موعد</label><input name="deadline" type="date" /></div></div>
          <label>وصف (اختياري)</label><textarea name="description" rows={2} maxLength={2000} />
          <button className="btn">إنشاء وإشعار الطلاب</button></>)}
        <div className="err" role="alert">{err}</div></form>
      {items.map((a) => (
        <div className="card" key={a.id}>
          <b>{a.title}</b> {!a.isActive && <span className="badge">مغلق</span>}<div className="muted">{a.meta}</div>
          <details><summary>تعديل</summary>
            <form onSubmit={(e) => edit(a.id, e)}>
              <label>العنوان</label><input name="title" defaultValue={a.title} required minLength={2} />
              <div className="row"><div><label>الدرجة العظمى</label><input name="maxGrade" type="number" min={1} defaultValue={a.maxGrade} /></div>
                <div><label>آخر موعد</label><input name="deadline" type="date" defaultValue={a.deadline?.slice(0, 10)} /></div></div>
              <label><input type="checkbox" name="isActive" defaultChecked={a.isActive} style={{ width: "auto" }} /> مفتوح للتسليم</label>
              <div className="row"><button className="btn">حفظ</button><button type="button" className="btn d" onClick={() => del(a.id, a.title)}>حذف</button></div>
            </form></details></div>
      ))}
    </div>
  );
}
