import LogoutButton from "./LogoutButton";
import ChangePassword from "./ChangePassword";

export default function Shell({ title, name, children }: { title: string; name: string; children: React.ReactNode }) {
  return (
    <>
      <header className="top"><b>📚 {title}</b><span className="sp" /><span>{name}</span><LogoutButton /></header>
      <main>{children}<ChangePassword /></main>
    </>
  );
}
