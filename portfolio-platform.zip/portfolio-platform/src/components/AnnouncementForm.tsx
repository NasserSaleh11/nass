"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { send } from "@/lib/client";

export default function AnnouncementForm({ classes, allowAll }: { classes: { id: string; label: string }[]; allowAll?: boolean }) {
  const router = useRouter(); const [err, setErr] = useState(""); const [ok, setOk] = useState(false);
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErr(""); setOk(false);
    const form = e.currentTarget, f = new FormData(form);
    const r = await send("/api/announcements", "POST", { classId: String(f.get("classId") || "") || undefined, title: f.get("title"), body: f.get("body") });
    if (!r.ok) return setErr(r.error);
    form.reset(); setOk(true); router.refresh();
  }
  return (
    <form className="card" onSubmit={onSubmit}><h3>إعلان للطلاب</h3>
      <div className="row"><div><label>الفصل</label><select name="classId">{allowAll && <option value="">كل الطلاب</option>}
        {classes.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}</select></div>
        <div><label>العنوان</label><input name="title" required maxLength={120} /></div></div>
      <label>النص</label><textarea name="body" rows={2} required maxLength={2000} />
      <div className="err" role="alert">{err}</div>{ok && <div role="status" style={{ color: "var(--ok)" }}>تم إرسال الإعلان.</div>}
      <button className="btn">إرسال</button></form>
  );
}
