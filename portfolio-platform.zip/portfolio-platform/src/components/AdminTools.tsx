"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { send } from "@/lib/client";

type O = { id: string; label: string };

function Mini({ title, url, children, map, onDone }: { title: string; url: string; children: React.ReactNode;
  map: (f: FormData) => unknown; onDone?: (d: Record<string, string>) => void }) {
  const router = useRouter(); const [err, setErr] = useState("");
  return (
    <form className="card" onSubmit={async (e) => {
      e.preventDefault(); setErr("");
      const form = e.currentTarget, r = await send(url, "POST", map(new FormData(form)));
      if (!r.ok) return setErr(r.error);
      form.reset(); onDone?.(r.data); router.refresh();
    }}><h3>{title}</h3>{children}<div className="err" role="alert">{err}</div><button className="btn">إضافة</button></form>
  );
}

export default function AdminTools({ teachers, classes, subjects }: { teachers: O[]; classes: O[]; subjects: O[] }) {
  const [pw, setPw] = useState("");
  return (
    <div>
      <Mini title="فصل جديد" url="/api/classes" map={(f) => ({ nameAr: f.get("nameAr"), year: f.get("year") })}>
        <div className="row"><div><label>اسم الفصل</label><input name="nameAr" required /></div><div><label>السنة الدراسية</label><input name="year" defaultValue="2026" required /></div></div></Mini>
      <Mini title="مادة جديدة" url="/api/subjects" map={(f) => ({ nameAr: f.get("nameAr"), code: f.get("code") })}>
        <div className="row"><div><label>اسم المادة</label><input name="nameAr" required /></div><div><label>الرمز (إنجليزي)</label><input name="code" dir="ltr" required /></div></div></Mini>
      <Mini title="معلم جديد" url="/api/teachers" map={(f) => ({ fullName: f.get("fullName"), email: f.get("email") })} onDone={(d) => setPw(d.tempPassword)}>
        <div className="row"><div><label>الاسم</label><input name="fullName" required minLength={3} /></div><div><label>البريد</label><input name="email" type="email" required /></div></div>
        {pw && <p role="status">كلمة المرور المؤقتة (تظهر مرة واحدة): <b dir="ltr">{pw}</b></p>}</Mini>
      <Mini title="تعيين معلم على فصل ومادة" url="/api/teacher-classes" map={(f) => ({ teacherUserId: f.get("t"), classId: f.get("c"), subjectId: f.get("s") })}>
        <div className="row">
          <div><label>المعلم</label><select name="t">{teachers.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select></div>
          <div><label>الفصل</label><select name="c">{classes.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select></div>
          <div><label>المادة</label><select name="s">{subjects.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select></div></div></Mini>
    </div>
  );
}
