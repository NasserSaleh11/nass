"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function AddStudent({ classes }: { classes: { id: string; label: string }[] }) {
  const router = useRouter();
  const [err, setErr] = useState("");
  const [pw, setPw] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr(""); setPw("");
    const form = e.currentTarget, f = new FormData(form);
    const res = await fetch("/api/students", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fullName: f.get("fullName"), email: f.get("email"), classId: f.get("classId") }) });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) return setErr(j.error ?? "تعذّرت الإضافة.");
    setPw(j.tempPassword); form.reset(); router.refresh();
  }

  return (
    <form className="card" onSubmit={onSubmit}>
      <h3>إضافة طالب</h3>
      <div className="row">
        <div><label>الاسم</label><input name="fullName" required minLength={3} /></div>
        <div><label>البريد</label><input name="email" type="email" required /></div>
        <div><label>الفصل</label><select name="classId">{classes.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}</select></div>
      </div>
      <div className="err" role="alert">{err}</div>
      {pw && <p role="status">كلمة المرور المؤقتة (تظهر مرة واحدة، سلّمها للطالب): <b dir="ltr">{pw}</b></p>}
      <button className="btn">إضافة</button>
    </form>
  );
}

export function DeleteStudent({ userId, name }: { userId: string; name: string }) {
  const router = useRouter();
  return (
    <button className="btn d" onClick={async () => {
      if (!confirm(`حذف الطالب «${name}» نهائيًا مع جميع أعماله؟ لا يمكن التراجع.`)) return;
      const res = await fetch(`/api/students/${userId}`, { method: "DELETE" });
      if (!res.ok) alert((await res.json().catch(() => ({}))).error ?? "تعذّر الحذف.");
      router.refresh();
    }}>حذف</button>
  );
}
