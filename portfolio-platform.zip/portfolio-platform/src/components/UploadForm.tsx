"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/constants";

type Opt = { id: string; label: string };

export default function UploadForm({ assignments, subjects }: { assignments: Opt[]; subjects: Opt[] }) {
  const router = useRouter();
  const [progress, setProgress] = useState<number | null>(null);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState(false);

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr(""); setOk(false);
    const form = e.currentTarget;
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/submissions");
    xhr.upload.onprogress = (ev) => ev.lengthComputable && setProgress(Math.round((ev.loaded / ev.total) * 100));
    xhr.onload = () => {
      setProgress(null);
      let j: { error?: string } = {};
      try { j = JSON.parse(xhr.responseText); } catch { /* ignore */ }
      if (xhr.status >= 200 && xhr.status < 300) { setOk(true); form.reset(); router.refresh(); }
      else setErr(j.error ?? "فشل الرفع. حاول مرة أخرى.");
    };
    xhr.onerror = () => { setProgress(null); setErr("انقطع الاتصال أثناء الرفع."); };
    setProgress(0);
    xhr.send(new FormData(form));
  }

  return (
    <form className="card" onSubmit={onSubmit}>
      <h3>رفع عمل</h3>
      <label htmlFor="assignmentId">الواجب (اختياري)</label>
      <select id="assignmentId" name="assignmentId">
        <option value="">رفع حر غير مرتبط بواجب</option>
        {assignments.map((a) => <option key={a.id} value={a.id}>{a.label}</option>)}
      </select>
      <label htmlFor="title">العنوان</label>
      <input id="title" name="title" required maxLength={120} />
      <div className="row">
        <div><label htmlFor="subjectId">المادة</label>
          <select id="subjectId" name="subjectId"><option value="">—</option>
            {subjects.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}</select></div>
        <div><label htmlFor="category">التصنيف</label>
          <select id="category" name="category">{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
      </div>
      <label htmlFor="description">وصف (اختياري)</label>
      <textarea id="description" name="description" rows={2} maxLength={1000} />
      <label htmlFor="file">الملف (PDF, DOC, DOCX, PPT, PPTX, JPG, PNG)</label>
      <input id="file" name="file" type="file" required accept=".pdf,.doc,.docx,.ppt,.pptx,.jpg,.jpeg,.png" />
      {progress !== null && <progress value={progress} max={100} aria-label="تقدم الرفع" />}
      <div className="err" role="alert">{err}</div>
      {ok && <div role="status" style={{ color: "var(--ok)" }}>تم رفع العمل بنجاح.</div>}
      <button className="btn" disabled={progress !== null}>رفع وتسليم</button>
    </form>
  );
}
