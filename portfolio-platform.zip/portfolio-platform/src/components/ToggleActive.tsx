"use client";
import { useRouter } from "next/navigation";

export default function ToggleActive({ userId, isActive }: { userId: string; isActive: boolean }) {
  const router = useRouter();
  return (
    <button className="btn o" onClick={async () => {
      if (!confirm(isActive ? "تعطيل هذا الحساب؟" : "تفعيل هذا الحساب؟")) return;
      const res = await fetch(`/api/users/${userId}`, { method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !isActive }) });
      if (!res.ok) alert((await res.json().catch(() => ({}))).error ?? "تعذّر التنفيذ.");
      router.refresh();
    }}>{isActive ? "تعطيل" : "تفعيل"}</button>
  );
}
