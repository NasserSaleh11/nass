"use client";
import { useRouter } from "next/navigation";

export default function LogoutButton() {
  const router = useRouter();
  return (
    <button className="btn o" style={{ color: "inherit", borderColor: "currentColor" }} onClick={async () => {
      await fetch("/api/auth/logout", { method: "POST" });
      router.replace("/login");
    }}>خروج</button>
  );
}
