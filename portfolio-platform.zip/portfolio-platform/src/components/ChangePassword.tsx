"use client";
import { useState } from "react";
import { send } from "@/lib/client";

export default function ChangePassword() {
  const [msg, setMsg] = useState(""); const [err, setErr] = useState("");
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setMsg(""); setErr("");
    const form = e.currentTarget, f = new FormData(form);
    if (f.get("next") !== f.get("again")) return setErr("تأكيد كلمة المرور لا يطابق.");
    const r = await send("/api/account/password", "POST", { current: f.get("current"), next: f.get("next") });
    if (!r.ok) return setErr(r.error);
    form.reset(); setMsg("تم تغيير كلمة المرور.");
  }
  return (
    <details className="card"><summary>🔑 تغيير كلمة المرور</summary>
      <form onSubmit={onSubmit}>
        <label>كلمة المرور الحالية</label><input name="current" type="password" autoComplete="current-password" required />
        <label>الجديدة (8 أحرف على الأقل)</label><input name="next" type="password" autoComplete="new-password" minLength={8} required />
        <label>تأكيد الجديدة</label><input name="again" type="password" autoComplete="new-password" minLength={8} required />
        <div className="err" role="alert">{err}</div>{msg && <div role="status" style={{ color: "var(--ok)" }}>{msg}</div>}
        <button className="btn">حفظ</button>
      </form></details>
  );
}
