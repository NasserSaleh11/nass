import { NextResponse } from "next/server";
import { ZodError } from "zod";
import type { Role } from "@prisma/client";
import { ForbiddenError } from "./authz";
import { getUser, type CurrentUser } from "./session";

export class ApiError extends Error {
  constructor(public status: number, msg: string) { super(msg); }
}

/** حماية CSRF إضافية فوق SameSite: يجب أن يطابق Origin المضيف في الطلبات المغيِّرة. */
function assertSameOrigin(req: Request) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return;
  const o = req.headers.get("origin");
  if (o && new URL(o).host !== (req.headers.get("x-forwarded-host") ?? req.headers.get("host"))) throw new ApiError(403, "طلب مرفوض.");
}

export async function authed(req: Request, ...roles: Role[]): Promise<CurrentUser> {
  assertSameOrigin(req);
  const u = await getUser();
  if (!u) throw new ApiError(401, "سجّل الدخول أولًا.");
  if (roles.length && !roles.includes(u.role)) throw new ApiError(403, "ليست لديك صلاحية لهذا الإجراء.");
  return u;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function route(fn: (req: Request, ctx: any) => Promise<Response>) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return async (req: Request, ctx: any) => {
    try { return await fn(req, ctx); }
    catch (e) {
      if (e instanceof ApiError) return NextResponse.json({ error: e.message }, { status: e.status });
      if (e instanceof ForbiddenError) return NextResponse.json({ error: "ليست لديك صلاحية." }, { status: 403 });
      if (e instanceof ZodError) return NextResponse.json({ error: "بيانات غير صالحة.", details: e.flatten().fieldErrors }, { status: 400 });
      console.error(e);
      return NextResponse.json({ error: "حدث خطأ غير متوقع." }, { status: 500 });
    }
  };
}
