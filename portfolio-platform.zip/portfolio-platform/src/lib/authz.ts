import { prisma } from "./prisma";
import type { Role } from "@prisma/client";

export type SessionUser = { id: string; role: Role; isActive: boolean };

export class ForbiddenError extends Error {
  constructor(msg = "FORBIDDEN") { super(msg); }
}

function assertActive(u: SessionUser) {
  if (!u.isActive) throw new ForbiddenError("ACCOUNT_DISABLED");
}

async function teacherProfileId(userId: string) {
  const t = await prisma.teacherProfile.findUnique({ where: { userId }, select: { id: true } });
  return t?.id ?? null;
}
async function studentProfileId(userId: string) {
  const s = await prisma.studentProfile.findUnique({ where: { userId }, select: { id: true } });
  return s?.id ?? null;
}

/** هل يملك المعلم صفًّا (يُدرّس فيه)؟ */
export async function teacherOwnsClass(user: SessionUser, classId: string) {
  const tid = await teacherProfileId(user.id);
  if (!tid) return false;
  return !!(await prisma.teacherClass.findFirst({ where: { teacherId: tid, classId }, select: { id: true } }));
}

/** عرض تسليم: صاحبه، أو معلم يدرّس صف الطالب، أو مدير. */
export async function canViewSubmission(user: SessionUser, submissionId: string) {
  assertActive(user);
  if (user.role === "ADMIN") return true;
  const sub = await prisma.submission.findUnique({
    where: { id: submissionId },
    select: { studentId: true, assignment: { select: { classId: true } } },
  });
  if (!sub) return false;

  if (user.role === "STUDENT") return (await studentProfileId(user.id)) === sub.studentId;

  // معلم: عبر صفوف الطالب المشتركة مع صفوفه
  const tid = await teacherProfileId(user.id);
  if (!tid) return false;
  const shared = await prisma.enrollment.findFirst({
    where: { studentId: sub.studentId, class: { teacherClasses: { some: { teacherId: tid } } } },
    select: { id: true },
  });
  return !!shared;
}

/** التقييم: معلم فقط، ويجب أن يدرّس صف الطالب (أو المدير عند الحاجة). */
export async function canGrade(user: SessionUser, submissionId: string) {
  assertActive(user);
  if (user.role === "STUDENT") return false;
  return canViewSubmission(user, submissionId);
}

/** تنزيل ملف = نفس صلاحية عرض التسليم. */
export async function canDownloadFile(user: SessionUser, fileId: string) {
  const f = await prisma.submissionFile.findUnique({ where: { id: fileId }, select: { submissionId: true } });
  return f ? canViewSubmission(user, f.submissionId) : false;
}

/** الطالب يستبدل ملفه فقط إذا لم يُقيَّم أو طُلبت إعادة التسليم، وقبل انتهاء المهلة عند منعها. */
export async function canResubmit(user: SessionUser, submissionId: string) {
  assertActive(user);
  if (user.role !== "STUDENT") return false;
  const sub = await prisma.submission.findUnique({
    where: { id: submissionId },
    include: { assignment: { select: { allowResubmit: true } } },
  });
  if (!sub || !sub.isCurrent) return false;
  if ((await studentProfileId(user.id)) !== sub.studentId) return false;
  if (sub.status === "RESUBMIT_REQUESTED") return true;
  return sub.status === "PENDING" && (sub.assignment?.allowResubmit ?? true);
}

/** تعليقات المعلم الداخلية لا تُرجَع للطالب أبدًا. */
export function commentVisibilityFilter(user: SessionUser) {
  return user.role === "STUDENT" ? { internal: false } : {};
}

export function requireRole(user: SessionUser, ...roles: Role[]) {
  assertActive(user);
  if (!roles.includes(user.role)) throw new ForbiddenError();
}
