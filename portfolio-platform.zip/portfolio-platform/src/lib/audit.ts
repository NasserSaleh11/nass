import { prisma } from "./prisma";
import type { Prisma } from "@prisma/client";

export function audit(actorId: string | null, action: string, entityType: string, entityId: string,
  before?: Prisma.InputJsonValue, after?: Prisma.InputJsonValue) {
  return prisma.auditLog.create({ data: { actorId, action, entityType, entityId, before, after } });
}
