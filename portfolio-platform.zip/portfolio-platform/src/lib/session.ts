import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { Role } from "@prisma/client";
import { prisma } from "./prisma";
import type { SessionUser } from "./authz";

const COOKIE = "session";
const key = () => {
  const s = process.env.AUTH_SECRET;
  if (!s || s.length < 32) throw new Error("AUTH_SECRET must be set (32+ chars)");
  return new TextEncoder().encode(s);
};

export async function createSession(userId: string, role: Role) {
  const token = await new SignJWT({ role })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(userId)
    .setIssuedAt()
    .setExpirationTime("8h")
    .sign(key());
  cookies().set(COOKIE, token, {
    httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 8,
    secure: process.env.NODE_ENV === "production",
  });
}

export function destroySession() { cookies().delete(COOKIE); }

export type CurrentUser = SessionUser & { fullName: string };

/** يتحقق من التوقيع ثم يعيد قراءة المستخدم من القاعدة (حتى يسري التعطيل فورًا). */
export async function getUser(): Promise<CurrentUser | null> {
  const t = cookies().get(COOKIE)?.value;
  if (!t) return null;
  try {
    const { payload } = await jwtVerify(t, key());
    const u = await prisma.user.findUnique({
      where: { id: String(payload.sub) },
      select: { id: true, role: true, isActive: true, fullName: true },
    });
    return u && u.isActive ? u : null;
  } catch { return null; }
}

export async function requireUser(...roles: Role[]): Promise<CurrentUser> {
  const u = await getUser();
  if (!u) redirect("/login");
  if (roles.length && !roles.includes(u.role)) redirect("/");
  return u;
}
