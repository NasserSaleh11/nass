export const CATEGORIES = ["مطوية", "ورقة عمل", "تمرين / واجب", "بحث / تقرير"] as const;
export const STATUS_LABEL: Record<string, string> = {
  PENDING: "قيد الانتظار",
  UNDER_REVIEW: "قيد المراجعة",
  EVALUATED: "مُقيَّم",
  RESUBMIT_REQUESTED: "مطلوب إعادة التسليم",
};
export const ROLE_HOME: Record<string, string> = { STUDENT: "/student", TEACHER: "/teacher", ADMIN: "/admin" };
