/* eslint-disable @typescript-eslint/no-explicit-any */
export async function send(url: string, method: string, body?: unknown) {
  const res = await fetch(url, { method, headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body) });
  const data: any = await res.json().catch(() => ({}));
  return { ok: res.ok, data, error: (data && data.error) || "تعذّر تنفيذ الطلب." };
}
