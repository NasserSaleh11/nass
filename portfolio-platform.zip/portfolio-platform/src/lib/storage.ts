import { promises as fs } from "fs";
import path from "path";
import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

// STORAGE_DRIVER=local  -> للتطوير فقط (لا يعمل على الاستضافة السحابية بلا قرص دائم)
// STORAGE_DRIVER=s3     -> أي تخزين متوافق مع S3 (Supabase Storage, R2, AWS S3...) بحاوية خاصة
const driver = process.env.STORAGE_DRIVER || "local";
const root = path.resolve(process.env.LOCAL_STORAGE_DIR || ".private-uploads");
const ttl = Number(process.env.SIGNED_URL_TTL_SECONDS) || 120;

let s3: S3Client | null = null;
const client = () => (s3 ??= new S3Client({
  region: process.env.STORAGE_REGION || "auto",
  endpoint: process.env.STORAGE_ENDPOINT,
  forcePathStyle: true,
  credentials: { accessKeyId: process.env.STORAGE_ACCESS_KEY ?? "", secretAccessKey: process.env.STORAGE_SECRET_KEY ?? "" },
}));
const bucket = () => process.env.STORAGE_BUCKET ?? "submissions";

function localPath(key: string) {
  const p = path.resolve(root, key);
  if (!p.startsWith(root + path.sep)) throw new Error("bad key");
  return p;
}
const disposition = (name: string, inline: boolean) =>
  `${inline ? "inline" : "attachment"}; filename*=UTF-8''${encodeURIComponent(name)}`;

export async function putObject(key: string, body: Buffer, contentType: string) {
  if (driver === "s3") {
    await client().send(new PutObjectCommand({ Bucket: bucket(), Key: key, Body: body, ContentType: contentType }));
  } else {
    const p = localPath(key);
    await fs.mkdir(path.dirname(p), { recursive: true });
    await fs.writeFile(p, body);
  }
}

export async function deleteObject(key: string) {
  try {
    if (driver === "s3") await client().send(new DeleteObjectCommand({ Bucket: bucket(), Key: key }));
    else await fs.rm(localPath(key), { force: true });
  } catch (e) { console.error("deleteObject failed", key, e); }
}

/** يُستدعى بعد التحقق من الصلاحية فقط. */
export async function downloadObject(key: string, name: string, mime: string, inline: boolean): Promise<Response> {
  if (driver === "s3") {
    const url = await getSignedUrl(client(), new GetObjectCommand({
      Bucket: bucket(), Key: key,
      ResponseContentDisposition: disposition(name, inline), ResponseContentType: mime,
    }), { expiresIn: ttl });
    return Response.redirect(url, 302);
  }
  const data = await fs.readFile(localPath(key));
  return new Response(new Uint8Array(data), {
    headers: {
      "Content-Type": mime,
      "Content-Disposition": disposition(name, inline),
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'none'; sandbox",
      "Cache-Control": "private, no-store",
    },
  });
}
