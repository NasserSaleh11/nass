import path from "path";

const starts = (b: Buffer, ...bytes: number[]) => bytes.every((v, i) => b[i] === v);
const ZIP = (b: Buffer) => starts(b, 0x50, 0x4b, 0x03, 0x04);
const OLE = (b: Buffer) => starts(b, 0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1);

/** الامتداد المسموح + توقيع المحتوى الفعلي (magic bytes) */
const TYPES: Record<string, { mime: string; sig: (b: Buffer) => boolean }> = {
  pdf: { mime: "application/pdf", sig: (b) => starts(b, 0x25, 0x50, 0x44, 0x46, 0x2d) },
  png: { mime: "image/png", sig: (b) => starts(b, 0x89, 0x50, 0x4e, 0x47) },
  jpg: { mime: "image/jpeg", sig: (b) => starts(b, 0xff, 0xd8, 0xff) },
  jpeg: { mime: "image/jpeg", sig: (b) => starts(b, 0xff, 0xd8, 0xff) },
  docx: { mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", sig: ZIP },
  pptx: { mime: "application/vnd.openxmlformats-officedocument.presentationml.presentation", sig: ZIP },
  doc: { mime: "application/msword", sig: OLE },
  ppt: { mime: "application/vnd.ms-powerpoint", sig: OLE },
};

export const maxBytes = () => (Number(process.env.MAX_UPLOAD_MB) || 15) * 1024 * 1024;
export const INLINE_MIMES = ["application/pdf", "image/png", "image/jpeg"];

export function checkFile(originalName: string, buf: Buffer) {
  const ext = path.extname(originalName).slice(1).toLowerCase();
  const t = TYPES[ext];
  if (!t) throw new Error("نوع الملف غير مسموح. المسموح: " + Object.keys(TYPES).join(", "));
  if (buf.length === 0) throw new Error("الملف فارغ.");
  if (!t.sig(buf)) throw new Error("محتوى الملف لا يطابق امتداده.");
  return { ext, mime: t.mime };
}

export const cleanName = (n: string) =>
  path.basename(n).replace(/[\u0000-\u001f<>:"/\\|?*]/g, "_").slice(0, 150) || "file";
