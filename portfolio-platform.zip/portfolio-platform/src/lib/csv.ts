/** يمنع حقن الصيغ في Excel (=, +, -, @) ويهرّب الفواصل وعلامات الاقتباس. */
export function csvCell(v: unknown): string {
  let s = String(v ?? "");
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
/** BOM في البداية ليعرض Excel العربية بشكل صحيح. */
export const toCsv = (rows: unknown[][]) => "\uFEFF" + rows.map((r) => r.map(csvCell).join(",")).join("\r\n");
