import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

const AREAS: Record<string, string> = { "/student": "STUDENT", "/teacher": "TEACHER", "/admin": "ADMIN" };

// خلف وكيل (Codespaces/Vercel) يجب بناء الرابط من ترويسات المضيف الأصلي
const to = (req: NextRequest, path: string) => {
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? req.nextUrl.host;
  const proto = req.headers.get("x-forwarded-proto") ?? req.nextUrl.protocol.replace(":", "");
  return new URL(path, `${proto}://${host}`);
};

export async function middleware(req: NextRequest) {
  const p = req.nextUrl.pathname;
  const area = Object.keys(AREAS).find((a) => p === a || p.startsWith(a + "/"));
  if (!area) return NextResponse.next();
  const login = to(req, "/login");
  const token = req.cookies.get("session")?.value;
  if (!token || !process.env.AUTH_SECRET) return NextResponse.redirect(login);
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(process.env.AUTH_SECRET));
    if (payload.role !== AREAS[area]) return NextResponse.redirect(to(req, "/"));
    return NextResponse.next();
  } catch { return NextResponse.redirect(login); }
}
export const config = { matcher: ["/student/:path*", "/teacher/:path*", "/admin/:path*"] };
