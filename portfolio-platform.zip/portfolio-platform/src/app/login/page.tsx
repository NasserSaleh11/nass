"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErr("");
    const f = new FormData(e.currentTarget);
    const res = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: f.get("email"), password: f.get("password") }) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setErr(j.error ?? "تعذّر تسجيل الدخول.");
    router.replace(j.redirect);
  }

  return (
    <main style={{ maxWidth: 420, marginTop: 40 }}>
      <h1>📚 منصة ملف الطالب</h1>
      <form className="card" onSubmit={onSubmit}>
        <label htmlFor="email">البريد الإلكتروني</label>
        <input id="email" name="email" type="email" autoComplete="username" required />
        <label htmlFor="password">كلمة المرور</label>
        <input id="password" name="password" type="password" autoComplete="current-password" required />
        <div className="err" role="alert">{err}</div>
        <button className="btn" disabled={busy}>{busy ? "جارٍ الدخول…" : "دخول"}</button>
      </form>
    </main>
  );
}
