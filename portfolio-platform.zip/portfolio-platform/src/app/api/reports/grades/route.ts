import { prisma } from "@/lib/prisma";
import { authed, route } from "@/lib/api";
import { toCsv } from "@/lib/csv";

export const GET = route(async (req) => {
  const user = await authed(req, "TEACHER", "ADMIN");
  let studentScope = {};
  if (user.role === "TEACHER") {
    const tcs = await prisma.teacherClass.findMany({ where: { teacher: { userId: user.id } }, select: { classId: true } });
    studentScope = { student: { enrollments: { some: { classId: { in: tcs.map((t) => t.classId) } } } } };
  }
  const evs = await prisma.evaluation.findMany({
    where: { submission: { isCurrent: true, ...studentScope } }, orderBy: { evaluatedAt: "desc" },
    include: { submission: { include: { assignment: { select: { title: true } }, subject: { select: { nameAr: true } },
      student: { include: { user: { select: { fullName: true, email: true } } } } } } } });
  const rows: unknown[][] = [["الطالب", "البريد", "العمل", "المادة", "الدرجة", "العظمى", "النسبة %", "تاريخ التقييم"]];
  for (const e of evs) {
    const g = Number(e.grade), m = Number(e.maxGrade), s = e.submission;
    rows.push([s.student.user.fullName, s.student.user.email, s.assignment?.title ?? s.title, s.subject?.nameAr ?? "",
      g, m, Math.round((g / m) * 100), e.evaluatedAt.toISOString().slice(0, 10)]);
  }
  return new Response(toCsv(rows), { headers: {
    "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="grades.csv"', "Cache-Control": "private, no-store" } });
});
