import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { canGrade } from "@/lib/authz";
import { audit } from "@/lib/audit";

const Body = z.object({
  submissionId: z.string(),
  status: z.enum(["UNDER_REVIEW", "EVALUATED", "RESUBMIT_REQUESTED"]),
  grade: z.number().min(0).optional(),
  maxGrade: z.number().positive().max(1000).optional(),   // للرفع الحر فقط
  feedback: z.string().trim().max(2000).optional(),
  internalNote: z.string().trim().max(2000).optional(),   // لا يراها الطالب
});

export const POST = route(async (req) => {
  const user = await authed(req, "TEACHER");
  const b = Body.parse(await req.json());
  if (!(await canGrade(user, b.submissionId))) throw new ApiError(403, "ليست لديك صلاحية تقييم هذا التسليم.");

  const teacher = await prisma.teacherProfile.findUniqueOrThrow({ where: { userId: user.id } });
  const sub = await prisma.submission.findUnique({
    where: { id: b.submissionId },
    include: { assignment: { select: { maxGrade: true } }, evaluation: true, student: { select: { userId: true } } },
  });
  if (!sub || !sub.isCurrent) throw new ApiError(404, "التسليم غير موجود أو استُبدل بنسخة أحدث.");

  const max = sub.assignment ? Number(sub.assignment.maxGrade) : (b.maxGrade ?? Number(sub.evaluation?.maxGrade ?? 20));
  if (b.status === "EVALUATED" && b.grade === undefined) throw new ApiError(400, "أدخل الدرجة.");
  if (b.grade !== undefined && b.grade > max) throw new ApiError(400, `الدرجة لا يمكن أن تتجاوز ${max}.`);

  const before = sub.evaluation ? { grade: Number(sub.evaluation.grade), feedback: sub.evaluation.feedback } : undefined;
  await prisma.$transaction(async (tx) => {
    if (b.grade !== undefined) {
      await tx.evaluation.upsert({
        where: { submissionId: sub.id },
        create: { submissionId: sub.id, teacherId: teacher.id, grade: b.grade, maxGrade: max, feedback: b.feedback },
        update: { teacherId: teacher.id, grade: b.grade, maxGrade: max, feedback: b.feedback },
      });
    } else if (sub.evaluation) {
      await tx.evaluation.update({ where: { submissionId: sub.id }, data: { feedback: b.feedback } });
    }
    await tx.submission.update({ where: { id: sub.id }, data: { status: b.status } });
    if (b.internalNote) await tx.comment.create({ data: { submissionId: sub.id, authorId: user.id, body: b.internalNote, internal: true } });
    await tx.notification.create({ data: {
      userId: sub.student.userId,
      type: b.status === "RESUBMIT_REQUESTED" ? "RESUBMIT_REQUESTED" : "EVALUATED",
      title: b.status === "RESUBMIT_REQUESTED" ? `طُلبت إعادة تسليم «${sub.title}»`
        : `تم تقييم «${sub.title}»${b.grade !== undefined ? `: ${b.grade}/${max}` : ""}`,
      link: "/student" } });
  });
  await audit(user.id, "GRADE_CHANGED", "Submission", sub.id, before,
    { grade: b.grade ?? null, status: b.status, feedback: b.feedback ?? null });
  return NextResponse.json({ ok: true });
});
