import { prisma } from "@/lib/prisma";
import { canDownloadFile } from "@/lib/authz";
import { ApiError, authed, route } from "@/lib/api";
import { downloadObject } from "@/lib/storage";
import { INLINE_MIMES } from "@/lib/files";

export const GET = route(async (req, { params }) => {
  const user = await authed(req);
  const f = await prisma.submissionFile.findUnique({ where: { id: params.id } });
  // نفس الرد (404) لغير الموجود ولغير المصرَّح به حتى لا يُكشف وجود الملف
  if (!f || !(await canDownloadFile(user, f.id))) throw new ApiError(404, "الملف غير موجود.");
  const inline = new URL(req.url).searchParams.get("inline") === "1" && INLINE_MIMES.includes(f.mimeType);
  return downloadObject(f.storageKey, f.originalName, f.mimeType, inline);
});
