import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const admin = await authed(req, "ADMIN");
  const b = z.object({ nameAr: z.string().trim().min(2).max(60), code: z.string().trim().toUpperCase().regex(/^[A-Z0-9_-]{2,20}$/, "رمز المادة: حروف إنجليزية وأرقام فقط") })
    .parse(await req.json());
  if (await prisma.subject.findUnique({ where: { code: b.code } })) throw new ApiError(409, "رمز المادة مستخدم.");
  const s = await prisma.subject.create({ data: { nameAr: b.nameAr, nameEn: b.nameAr, code: b.code } });
  await audit(admin.id, "SUBJECT_CREATED", "Subject", s.id, undefined, b);
  return NextResponse.json({ id: s.id }, { status: 201 });
});
