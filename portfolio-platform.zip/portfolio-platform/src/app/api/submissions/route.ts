import { randomUUID, createHash } from "crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { canResubmit } from "@/lib/authz";
import { CATEGORIES } from "@/lib/constants";
import { checkFile, cleanName, maxBytes } from "@/lib/files";
import { deleteObject, putObject } from "@/lib/storage";

export const POST = route(async (req) => {
  const user = await authed(req, "STUDENT");
  const fd = await req.formData();
  const str = (k: string) => { const v = fd.get(k); return typeof v === "string" && v.trim() ? v.trim() : undefined; };
  const meta = z.object({
    title: z.string({ required_error: "العنوان مطلوب" }).min(1, "العنوان مطلوب").max(120),
    description: z.string().max(1000).optional(),
    category: z.enum(CATEGORIES),
    subjectId: z.string().optional(),
    assignmentId: z.string().optional(),
  }).parse({ title: str("title"), description: str("description"), category: str("category"),
    subjectId: str("subjectId"), assignmentId: str("assignmentId") });

  const file = fd.get("file");
  if (!(file instanceof File)) throw new ApiError(400, "اختر ملفًا للرفع.");
  if (file.size > maxBytes()) throw new ApiError(413, `حجم الملف أكبر من ${Math.round(maxBytes() / 1048576)} ميغابايت.`);
  const buf = Buffer.from(await file.arrayBuffer());
  let type: { ext: string; mime: string };
  try { type = checkFile(file.name, buf); } catch (e) { throw new ApiError(400, (e as Error).message); }

  const student = await prisma.studentProfile.findUnique({ where: { userId: user.id } });
  if (!student) throw new ApiError(403, "لا يوجد ملف طالب لهذا الحساب.");

  const assignment = meta.assignmentId
    ? await prisma.assignment.findUnique({ where: { id: meta.assignmentId }, include: { teacher: { select: { userId: true } } } })
    : null;
  let prev: { id: string; version: number } | null = null;
  if (meta.assignmentId) {
    if (!assignment || !assignment.isActive) throw new ApiError(404, "الواجب غير موجود.");
    const enrolled = await prisma.enrollment.findUnique({
      where: { studentId_classId: { studentId: student.id, classId: assignment.classId } } });
    if (!enrolled) throw new ApiError(403, "هذا الواجب ليس لصفك.");
    prev = await prisma.submission.findFirst({
      where: { studentId: student.id, assignmentId: assignment.id, isCurrent: true }, select: { id: true, version: true } });
    if (prev && !(await canResubmit(user, prev.id)))
      throw new ApiError(409, "سلّمت هذا الواجب مسبقًا. لا يمكن الاستبدال إلا إذا طلب المعلم ذلك.");
  }

  const key = `${student.id}/${randomUUID()}.${type.ext}`;
  await putObject(key, buf, type.mime);
  try {
    const created = await prisma.$transaction(async (tx) => {
      if (prev) await tx.submission.update({ where: { id: prev.id }, data: { isCurrent: false } });
      const s = await tx.submission.create({ data: {
        studentId: student.id, assignmentId: assignment?.id, subjectId: meta.subjectId ?? assignment?.subjectId,
        title: meta.title, description: meta.description, category: meta.category,
        version: prev ? prev.version + 1 : 1, supersedesId: prev?.id,
        files: { create: { storageKey: key, originalName: cleanName(file.name), mimeType: type.mime,
          sizeBytes: buf.length, sha256: createHash("sha256").update(buf).digest("hex") } },
      } });
      if (assignment) await tx.notification.create({ data: {
        userId: assignment.teacher.userId, type: "SUBMISSION_RECEIVED",
        title: `${user.fullName} سلّم «${meta.title}»`, link: "/teacher" } });
      return s;
    });
    return NextResponse.json({ id: created.id }, { status: 201 });
  } catch (e) { await deleteObject(key); throw e; }
});
