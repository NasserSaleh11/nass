import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const admin = await authed(req, "ADMIN");
  const b = z.object({ nameAr: z.string().trim().min(2).max(60), year: z.string().trim().min(2).max(20) }).parse(await req.json());
  const c = await prisma.class.create({ data: { nameAr: b.nameAr, nameEn: b.nameAr, year: b.year } });
  await audit(admin.id, "CLASS_CREATED", "Class", c.id, undefined, b);
  return NextResponse.json({ id: c.id }, { status: 201 });
});
