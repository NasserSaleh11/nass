import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { createSession } from "@/lib/session";
import { ROLE_HOME } from "@/lib/constants";
import { ApiError, route } from "@/lib/api";
import { audit } from "@/lib/audit";

// تحديد المحاولات في الذاكرة (يكفي لخادم واحد؛ استخدم Redis/Upstash عند التوسع)
const attempts = new Map<string, { n: number; until: number }>();
// هاش وهمي: يجعل زمن الرد متقاربًا سواء وُجد البريد أم لا
const DUMMY = bcrypt.hashSync("dummy-password-for-timing", 12);

export const POST = route(async (req) => {
  const { email, password } = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(200) })
    .parse(await req.json());
  const k = (req.headers.get("x-forwarded-for") ?? "local") + "|" + email;
  const a = attempts.get(k);
  if (a && a.until > Date.now()) throw new ApiError(429, "محاولات كثيرة. حاول بعد دقيقة.");

  const user = await prisma.user.findUnique({ where: { email } });
  const ok = await bcrypt.compare(password, user?.passwordHash ?? DUMMY);
  if (!user || !ok || !user.isActive) {
    const n = (a?.n ?? 0) + 1;
    attempts.set(k, { n: n >= 5 ? 0 : n, until: n >= 5 ? Date.now() + 60_000 : 0 });
    if (user) await audit(user.id, "LOGIN_FAILED", "User", user.id);
    throw new ApiError(401, "البريد أو كلمة المرور غير صحيحة.");
  }
  attempts.delete(k);
  await createSession(user.id, user.role);
  await audit(user.id, "LOGIN", "User", user.id);
  return NextResponse.json({ redirect: ROLE_HOME[user.role] });
});
