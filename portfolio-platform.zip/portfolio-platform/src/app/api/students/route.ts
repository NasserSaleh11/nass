import { randomBytes } from "crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { teacherOwnsClass } from "@/lib/authz";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const user = await authed(req, "TEACHER", "ADMIN");
  const b = z.object({
    fullName: z.string().trim().min(3).max(80),
    email: z.string().trim().toLowerCase().email(),
    classId: z.string(),
  }).parse(await req.json());
  if (user.role === "TEACHER" && !(await teacherOwnsClass(user, b.classId)))
    throw new ApiError(403, "هذا الفصل ليس من فصولك.");

  const tempPassword = randomBytes(9).toString("base64url");
  try {
    const created = await prisma.user.create({ data: {
      email: b.email, fullName: b.fullName, role: "STUDENT", passwordHash: await bcrypt.hash(tempPassword, 12),
      student: { create: { enrollments: { create: { classId: b.classId } } } },
    } });
    await audit(user.id, "STUDENT_CREATED", "User", created.id, undefined, { email: b.email, classId: b.classId });
    return NextResponse.json({ id: created.id, tempPassword }, { status: 201 }); // تُعرض مرة واحدة فقط
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") throw new ApiError(409, "البريد مستخدم مسبقًا.");
    throw e;
  }
});
