import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";
import { deleteObject } from "@/lib/storage";

// id = معرّف مستخدم الطالب. المعلم يحذف طلاب فصوله فقط.
export const DELETE = route(async (req, { params }) => {
  const user = await authed(req, "TEACHER", "ADMIN");
  const target = await prisma.user.findFirst({ where: { id: params.id, role: "STUDENT" } });
  if (!target) throw new ApiError(404, "الطالب غير موجود.");
  if (user.role === "TEACHER") {
    const shared = await prisma.enrollment.findFirst({ where: {
      student: { userId: target.id }, class: { teacherClasses: { some: { teacher: { userId: user.id } } } } } });
    if (!shared) throw new ApiError(403, "هذا الطالب ليس في فصولك.");
  }
  const files = await prisma.submissionFile.findMany({
    where: { submission: { student: { userId: target.id } } }, select: { storageKey: true } });
  await audit(user.id, "STUDENT_DELETED", "User", target.id, { email: target.email, fullName: target.fullName });
  await prisma.user.delete({ where: { id: target.id } });   // يحذف التسليمات والتقييمات بالتتالي
  await Promise.all(files.map((f) => deleteObject(f.storageKey)));
  return NextResponse.json({ ok: true });
});
