import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

async function own(userId: string, id: string) {
  const a = await prisma.assignment.findUnique({ where: { id }, include: { teacher: { select: { userId: true } } } });
  if (!a || a.teacher.userId !== userId) throw new ApiError(404, "الواجب غير موجود.");
  return a;
}

export const PATCH = route(async (req, { params }) => {
  const user = await authed(req, "TEACHER");
  const a = await own(user.id, params.id);
  const b = z.object({
    title: z.string().trim().min(2).max(120).optional(), description: z.string().trim().max(2000).nullable().optional(),
    maxGrade: z.number().positive().max(1000).optional(), deadline: z.string().datetime().nullable().optional(),
    isActive: z.boolean().optional(),
  }).parse(await req.json());
  if (b.maxGrade !== undefined && b.maxGrade !== Number(a.maxGrade) &&
      (await prisma.evaluation.count({ where: { submission: { assignmentId: a.id } } })) > 0)
    throw new ApiError(409, "لا يمكن تغيير الدرجة العظمى بعد تقييم تسليمات هذا الواجب.");
  await prisma.assignment.update({ where: { id: a.id }, data: {
    title: b.title, description: b.description, maxGrade: b.maxGrade, isActive: b.isActive,
    deadline: b.deadline === undefined ? undefined : b.deadline === null ? null : new Date(b.deadline) } });
  await audit(user.id, "ASSIGNMENT_EDITED", "Assignment", a.id, { title: a.title, maxGrade: Number(a.maxGrade) }, b);
  return NextResponse.json({ ok: true });
});

export const DELETE = route(async (req, { params }) => {
  const user = await authed(req, "TEACHER");
  const a = await own(user.id, params.id);
  await audit(user.id, "ASSIGNMENT_DELETED", "Assignment", a.id, { title: a.title });
  await prisma.assignment.delete({ where: { id: a.id } });   // التسليمات تبقى كأعمال حرة (SetNull)
  return NextResponse.json({ ok: true });
});
