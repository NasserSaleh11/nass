import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const user = await authed(req, "TEACHER");
  const b = z.object({
    title: z.string().trim().min(2).max(120), description: z.string().trim().max(2000).optional(),
    classId: z.string(), subjectId: z.string(),
    maxGrade: z.number().positive().max(1000), deadline: z.string().datetime().optional(),
  }).parse(await req.json());
  const tp = await prisma.teacherProfile.findUniqueOrThrow({ where: { userId: user.id } });
  const tc = await prisma.teacherClass.findUnique({ where: { teacherId_classId_subjectId: { teacherId: tp.id, classId: b.classId, subjectId: b.subjectId } } });
  if (!tc) throw new ApiError(403, "لا تُدرّس هذه المادة في هذا الفصل.");
  const a = await prisma.assignment.create({ data: {
    title: b.title, description: b.description, classId: b.classId, subjectId: b.subjectId, teacherId: tp.id,
    maxGrade: b.maxGrade, deadline: b.deadline ? new Date(b.deadline) : null } });
  const enr = await prisma.enrollment.findMany({ where: { classId: b.classId }, select: { student: { select: { userId: true } } } });
  if (enr.length) await prisma.notification.createMany({ data: enr.map((e) => ({
    userId: e.student.userId, type: "NEW_ASSIGNMENT" as const, title: `واجب جديد: ${a.title}`, link: "/student" })) });
  await audit(user.id, "ASSIGNMENT_CREATED", "Assignment", a.id, undefined, { title: a.title });
  return NextResponse.json({ id: a.id }, { status: 201 });
});
