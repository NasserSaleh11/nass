import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const admin = await authed(req, "ADMIN");
  const b = z.object({ teacherUserId: z.string(), classId: z.string(), subjectId: z.string() }).parse(await req.json());
  const tp = await prisma.teacherProfile.findUnique({ where: { userId: b.teacherUserId } });
  if (!tp) throw new ApiError(404, "المعلم غير موجود.");
  const exists = await prisma.teacherClass.findUnique({ where: { teacherId_classId_subjectId: { teacherId: tp.id, classId: b.classId, subjectId: b.subjectId } } });
  if (exists) throw new ApiError(409, "التعيين موجود مسبقًا.");
  const tc = await prisma.teacherClass.create({ data: { teacherId: tp.id, classId: b.classId, subjectId: b.subjectId } });
  await audit(admin.id, "TEACHER_ASSIGNED", "TeacherClass", tc.id, undefined, b);
  return NextResponse.json({ id: tc.id }, { status: 201 });
});
