import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { teacherOwnsClass } from "@/lib/authz";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const user = await authed(req, "TEACHER", "ADMIN");
  const b = z.object({ classId: z.string().optional(), title: z.string().trim().min(2).max(120), body: z.string().trim().min(1).max(2000) })
    .parse(await req.json());
  if (user.role === "TEACHER" && (!b.classId || !(await teacherOwnsClass(user, b.classId))))
    throw new ApiError(403, "اختر فصلًا من فصولك.");
  const a = await prisma.announcement.create({ data: { authorId: user.id, classId: b.classId, title: b.title, body: b.body } });
  const students = await prisma.studentProfile.findMany({
    where: b.classId ? { enrollments: { some: { classId: b.classId } } } : {}, select: { userId: true } });
  if (students.length) await prisma.notification.createMany({ data: students.map((s) => ({
    userId: s.userId, type: "ANNOUNCEMENT" as const, title: `📢 ${b.title}`, link: "/student" })) });
  await audit(user.id, "ANNOUNCEMENT_SENT", "Announcement", a.id);
  return NextResponse.json({ id: a.id }, { status: 201 });
});
