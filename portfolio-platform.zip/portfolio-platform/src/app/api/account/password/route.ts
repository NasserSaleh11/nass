import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const user = await authed(req);
  const b = z.object({ current: z.string().min(1).max(200), next: z.string().min(8, "كلمة المرور 8 أحرف على الأقل").max(200) }).parse(await req.json());
  const u = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });
  if (!(await bcrypt.compare(b.current, u.passwordHash))) throw new ApiError(400, "كلمة المرور الحالية غير صحيحة.");
  await prisma.user.update({ where: { id: u.id }, data: { passwordHash: await bcrypt.hash(b.next, 12) } });
  await audit(user.id, "PASSWORD_CHANGED", "User", user.id);
  return NextResponse.json({ ok: true });
});
