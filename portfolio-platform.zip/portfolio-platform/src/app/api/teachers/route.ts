import { randomBytes } from "crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const POST = route(async (req) => {
  const admin = await authed(req, "ADMIN");
  const b = z.object({ fullName: z.string().trim().min(3).max(80), email: z.string().trim().toLowerCase().email() }).parse(await req.json());
  const tempPassword = randomBytes(9).toString("base64url");
  try {
    const u = await prisma.user.create({ data: { email: b.email, fullName: b.fullName, role: "TEACHER",
      passwordHash: await bcrypt.hash(tempPassword, 12), teacher: { create: {} } } });
    await audit(admin.id, "TEACHER_CREATED", "User", u.id, undefined, { email: b.email });
    return NextResponse.json({ id: u.id, tempPassword }, { status: 201 });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") throw new ApiError(409, "البريد مستخدم مسبقًا.");
    throw e;
  }
});
