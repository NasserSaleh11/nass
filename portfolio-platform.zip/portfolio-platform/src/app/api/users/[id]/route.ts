import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, authed, route } from "@/lib/api";
import { audit } from "@/lib/audit";

export const PATCH = route(async (req, { params }) => {
  const admin = await authed(req, "ADMIN");
  const { isActive } = z.object({ isActive: z.boolean() }).parse(await req.json());
  if (params.id === admin.id) throw new ApiError(400, "لا يمكنك تعطيل حسابك.");
  const u = await prisma.user.update({ where: { id: params.id }, data: { isActive } }).catch(() => null);
  if (!u) throw new ApiError(404, "المستخدم غير موجود.");
  await audit(admin.id, isActive ? "USER_ACTIVATED" : "USER_DEACTIVATED", "User", u.id);
  return NextResponse.json({ ok: true });
});
