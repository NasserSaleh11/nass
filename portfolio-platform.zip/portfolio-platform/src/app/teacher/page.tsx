import { SubmissionStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { STATUS_LABEL } from "@/lib/constants";
import { INLINE_MIMES } from "@/lib/files";
import Shell from "@/components/Shell";
import GradeForm from "@/components/GradeForm";
import AssignmentManager from "@/components/AssignmentManager";
import AnnouncementForm from "@/components/AnnouncementForm";
import { AddStudent, DeleteStudent } from "@/components/StudentTools";

export default async function TeacherPage({ searchParams }: { searchParams: { status?: string; classId?: string } }) {
  const user = await requireUser("TEACHER");
  const tp = await prisma.teacherProfile.findUniqueOrThrow({
    where: { userId: user.id }, include: { teacherClasses: { include: { class: true, subject: true } } } });
  const classes = [...new Map(tp.teacherClasses.map((t) => [t.class.id, t.class])).values()];
  const classIds = classes.map((c) => c.id);
  const status = Object.keys(STATUS_LABEL).includes(searchParams.status ?? "") ? (searchParams.status as SubmissionStatus) : undefined;
  const classFilter = classIds.includes(searchParams.classId ?? "") ? searchParams.classId! : undefined;
  const scope = { enrollments: { some: { classId: classFilter ?? { in: classIds } } } };
  const allScope = { enrollments: { some: { classId: { in: classIds } } } };

  const [subs, students, counts, assignments, evals] = await Promise.all([
    prisma.submission.findMany({
      where: { isCurrent: true, status, student: scope }, orderBy: { submittedAt: "desc" }, take: 100,
      include: { files: true, evaluation: true, assignment: { select: { title: true, maxGrade: true } },
        student: { include: { user: { select: { fullName: true } } } } } }),
    prisma.studentProfile.findMany({
      where: scope, include: { user: { select: { id: true, fullName: true, email: true } }, enrollments: { include: { class: true } } },
      orderBy: { user: { fullName: "asc" } } }),
    prisma.submission.groupBy({ by: ["status"], where: { isCurrent: true, student: allScope }, _count: true }),
    prisma.assignment.findMany({
      where: { teacherId: tp.id }, orderBy: { createdAt: "desc" },
      include: { subject: { select: { nameAr: true } }, class: { select: { nameAr: true, _count: { select: { enrollments: true } } } },
        _count: { select: { submissions: { where: { isCurrent: true } } } } } }),
    prisma.evaluation.findMany({ where: { submission: { isCurrent: true, student: allScope } },
      select: { grade: true, maxGrade: true, submission: { select: { studentId: true } } } }),
  ]);
  const c = (s: string) => counts.find((x) => x.status === s)?._count ?? 0;
  const pct = new Map<string, number[]>();
  for (const e of evals) {
    const k = e.submission.studentId, arr = pct.get(k) ?? [];
    arr.push((Number(e.grade) / Number(e.maxGrade)) * 100); pct.set(k, arr);
  }
  const avgOf = (id: string) => { const a = pct.get(id); return a?.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) + "%" : "—"; };
  const now = new Date();

  return (
    <Shell title="لوحة المعلم" name={user.fullName}>
      <div className="grid">
        <div className="card stat"><b>{students.length}</b>الطلاب</div>
        <div className="card stat"><b>{c("PENDING")}</b>تسليمات جديدة</div>
        <div className="card stat"><b>{c("UNDER_REVIEW")}</b>قيد المراجعة</div>
        <div className="card stat"><b>{c("EVALUATED")}</b>مكتملة</div>
        <div className="card stat"><b>{c("RESUBMIT_REQUESTED")}</b>بانتظار إعادة التسليم</div>
      </div>

      <form className="card row" method="get">
        <div><label htmlFor="classId">الفصل</label>
          <select id="classId" name="classId" defaultValue={classFilter ?? ""}><option value="">كل الفصول</option>
            {classes.map((k) => <option key={k.id} value={k.id}>{k.nameAr}</option>)}</select></div>
        <div><label htmlFor="status">الحالة</label>
          <select id="status" name="status" defaultValue={status ?? ""}><option value="">الكل</option>
            {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
        <button className="btn">تصفية</button>
      </form>

      <h3>التسليمات</h3>
      {subs.length === 0 ? <div className="card muted">لا توجد تسليمات مطابقة.</div> : subs.map((s) => {
        const fixed = !!s.assignment;
        const max = fixed ? Number(s.assignment!.maxGrade) : Number(s.evaluation?.maxGrade ?? 20);
        return (
          <div className="card" key={s.id}>
            <div className="row"><b>{s.student.user.fullName} — {s.title}</b><span className={`badge ${s.status}`}>{STATUS_LABEL[s.status]}</span></div>
            <div className="muted">{s.assignment?.title ?? "رفع حر"} • {s.category} • {s.submittedAt.toLocaleDateString("ar")} • نسخة {s.version}
              {s.evaluation && <> • الدرجة {Number(s.evaluation.grade)}/{Number(s.evaluation.maxGrade)}</>}</div>
            {s.files.map((f) => (
              <div key={f.id}>📎 <a href={`/api/files/${f.id}`}>{f.originalName}</a>
                {INLINE_MIMES.includes(f.mimeType) && <> • <a href={`/api/files/${f.id}?inline=1`} target="_blank" rel="noreferrer">عرض</a></>}</div>
            ))}
            <GradeForm submissionId={s.id} max={max} fixedMax={fixed}
              grade={s.evaluation ? Number(s.evaluation.grade) : undefined} feedback={s.evaluation?.feedback ?? undefined} status={s.status} />
          </div>
        );
      })}

      <h3>الواجبات</h3>
      <AssignmentManager
        options={tp.teacherClasses.map((t) => ({ classId: t.classId, subjectId: t.subjectId, label: `${t.class.nameAr} — ${t.subject.nameAr}` }))}
        items={assignments.map((a) => {
          const enrolled = a.class._count.enrollments, done = a._count.submissions;
          const overdue = a.deadline && a.deadline < now ? Math.max(enrolled - done, 0) : 0;
          return { id: a.id, title: a.title, description: a.description, maxGrade: Number(a.maxGrade), deadline: a.deadline?.toISOString() ?? null,
            isActive: a.isActive, meta: `${a.class.nameAr} • ${a.subject.nameAr} • من ${Number(a.maxGrade)} • سلّم ${done}/${enrolled}${overdue ? ` • متأخر ${overdue}` : ""}` };
        })} />

      <AnnouncementForm classes={classes.map((k) => ({ id: k.id, label: k.nameAr }))} />

      <h3>التقارير</h3>
      <div className="card tw"><a className="btn o" href="/api/reports/grades">تصدير الدرجات (CSV / Excel)</a>
        <table><thead><tr><th>الطالب</th><th>الأعمال المقيَّمة</th><th>المعدل</th></tr></thead>
          <tbody>{students.map((st) => (
            <tr key={st.id}><td>{st.user.fullName}</td><td>{pct.get(st.id)?.length ?? 0}</td><td>{avgOf(st.id)}</td></tr>))}</tbody></table></div>

      <h3>الطلاب</h3>
      <AddStudent classes={classes.map((k) => ({ id: k.id, label: k.nameAr }))} />
      <div className="card tw"><table>
        <thead><tr><th>الاسم</th><th>البريد</th><th>الفصل</th><th></th></tr></thead>
        <tbody>{students.map((st) => (
          <tr key={st.id}><td>{st.user.fullName}</td><td dir="ltr">{st.user.email}</td>
            <td>{st.enrollments.map((e) => e.class.nameAr).join("، ")}</td>
            <td><DeleteStudent userId={st.user.id} name={st.user.fullName} /></td></tr>
        ))}</tbody></table></div>
    </Shell>
  );
}
