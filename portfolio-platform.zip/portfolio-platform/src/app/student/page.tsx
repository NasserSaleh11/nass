import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { STATUS_LABEL } from "@/lib/constants";
import { INLINE_MIMES } from "@/lib/files";
import Shell from "@/components/Shell";
import UploadForm from "@/components/UploadForm";

export default async function StudentPage() {
  const user = await requireUser("STUDENT");
  const sp = await prisma.studentProfile.findUniqueOrThrow({
    where: { userId: user.id }, include: { enrollments: { select: { classId: true } } } });
  const [subs, assignments, subjects, notifs, announcements] = await Promise.all([
    prisma.submission.findMany({
      where: { studentId: sp.id, isCurrent: true }, orderBy: { submittedAt: "desc" },
      include: { files: true, evaluation: true, subject: { select: { nameAr: true } } } }),
    prisma.assignment.findMany({
      where: { isActive: true, classId: { in: sp.enrollments.map((e) => e.classId) } }, orderBy: { deadline: "asc" } }),
    prisma.subject.findMany({ orderBy: { nameAr: "asc" } }),
    prisma.notification.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 5 }),
    prisma.announcement.findMany({ where: { OR: [{ classId: null }, { classId: { in: sp.enrollments.map((e) => e.classId) } }] }, orderBy: { createdAt: "desc" }, take: 5 }),
  ]);

  const evaluated = subs.filter((s) => s.evaluation);
  const avg = evaluated.length
    ? Math.round(evaluated.reduce((a, s) => a + (Number(s.evaluation!.grade) / Number(s.evaluation!.maxGrade)) * 100, 0) / evaluated.length)
    : null;
  const submittedIds = new Set(subs.map((s) => s.assignmentId));
  const todo = assignments.filter((a) => !submittedIds.has(a.id) || subs.find((s) => s.assignmentId === a.id)?.status === "RESUBMIT_REQUESTED");

  return (
    <Shell title="ملف الطالب" name={user.fullName}>
      <h2>مرحبًا {user.fullName}</h2>
      <div className="grid">
        <div className="card stat"><b>{subs.length}</b>إجمالي الأعمال</div>
        <div className="card stat"><b>{evaluated.length}</b>مُقيَّمة</div>
        <div className="card stat"><b>{subs.filter((s) => s.status !== "EVALUATED").length}</b>بانتظار التقييم</div>
        <div className="card stat"><b>{avg === null ? "—" : `${avg}%`}</b>المعدل</div>
      </div>

      <div className="card"><h3>المطلوب تسليمه</h3>
        {todo.length ? todo.map((a) => (
          <p key={a.id}>{a.title} {a.deadline && <span className="muted">— حتى {a.deadline.toLocaleDateString("ar")}</span>}</p>
        )) : <p className="muted">لا توجد واجبات مطلوبة.</p>}
      </div>

      {announcements.length > 0 && <div className="card"><h3>الإعلانات</h3>
        {announcements.map((a) => <p key={a.id}><b>{a.title}</b> — {a.body} <span className="muted">{a.createdAt.toLocaleDateString("ar")}</span></p>)}</div>}

      <div className="card"><h3>الإشعارات</h3>
        {notifs.length ? notifs.map((n) => <p key={n.id}>{n.title} <span className="muted">{n.createdAt.toLocaleDateString("ar")}</span></p>)
          : <p className="muted">لا توجد إشعارات.</p>}
      </div>

      <UploadForm
        assignments={todo.map((a) => ({ id: a.id, label: a.title }))}
        subjects={subjects.map((s) => ({ id: s.id, label: s.nameAr }))} />

      <h3>ملفي</h3>
      {subs.length === 0 ? <div className="card muted">لم ترفع أي عمل بعد.</div> : (
        <div className="cards">
          {subs.map((s) => (
            <div className="card" key={s.id}>
              <div className="row"><b>{s.title}</b><span className={`badge ${s.status}`}>{STATUS_LABEL[s.status]}</span></div>
              <div className="muted">{s.subject?.nameAr ?? "—"} • {s.category} • {s.submittedAt.toLocaleDateString("ar")} • نسخة {s.version}</div>
              {s.files.map((f) => (
                <div key={f.id}>📎 <a href={`/api/files/${f.id}`}>{f.originalName}</a>
                  {INLINE_MIMES.includes(f.mimeType) && <> • <a href={`/api/files/${f.id}?inline=1`} target="_blank" rel="noreferrer">عرض</a></>}</div>
              ))}
              {s.evaluation && <p><b>الدرجة: {Number(s.evaluation.grade)}/{Number(s.evaluation.maxGrade)}</b></p>}
              {s.evaluation?.feedback && <blockquote>{s.evaluation.feedback}</blockquote>}
              {s.status === "RESUBMIT_REQUESTED" && <p className="muted">طلب المعلم نسخة معدّلة: ارفعها من النموذج أعلاه واختر نفس الواجب.</p>}
            </div>
          ))}
        </div>
      )}
    </Shell>
  );
}
