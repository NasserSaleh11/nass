import { redirect } from "next/navigation";
import { getUser } from "@/lib/session";
import { ROLE_HOME } from "@/lib/constants";

export default async function Home() {
  const u = await getUser();
  redirect(u ? ROLE_HOME[u.role] : "/login");
}
