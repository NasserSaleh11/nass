import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import Shell from "@/components/Shell";
import ToggleActive from "@/components/ToggleActive";
import AdminTools from "@/components/AdminTools";
import AnnouncementForm from "@/components/AnnouncementForm";

const ROLE = { STUDENT: "طالب", TEACHER: "معلم", ADMIN: "مدير" } as const;

export default async function AdminPage() {
  const user = await requireUser("ADMIN");
  const [users, logs, subCount, evalCount, bytes, classes, subjects, assigns] = await Promise.all([
    prisma.user.findMany({ orderBy: [{ role: "asc" }, { fullName: "asc" }], take: 200 }),
    prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 40, include: { actor: { select: { fullName: true } } } }),
    prisma.submission.count({ where: { isCurrent: true } }),
    prisma.evaluation.count(),
    prisma.submissionFile.aggregate({ _sum: { sizeBytes: true } }),
    prisma.class.findMany({ orderBy: { nameAr: "asc" } }),
    prisma.subject.findMany({ orderBy: { nameAr: "asc" } }),
    prisma.teacherClass.findMany({ include: { teacher: { include: { user: { select: { fullName: true } } } }, class: true, subject: true } }),
  ]);
  const teachers = users.filter((u) => u.role === "TEACHER");

  return (
    <Shell title="لوحة المدير" name={user.fullName}>
      <div className="grid">
        <div className="card stat"><b>{users.length}</b>الحسابات</div>
        <div className="card stat"><b>{users.filter((u) => !u.isActive).length}</b>معطّلة</div>
        <div className="card stat"><b>{subCount}</b>التسليمات</div>
        <div className="card stat"><b>{evalCount}</b>التقييمات</div>
        <div className="card stat"><b>{((bytes._sum.sizeBytes ?? 0) / 1048576).toFixed(1)} MB</b>التخزين</div>
      </div>

      <h3>إدارة الفصول والمواد والمعلمين</h3>
      <AdminTools teachers={teachers.map((t) => ({ id: t.id, label: t.fullName }))}
        classes={classes.map((c) => ({ id: c.id, label: c.nameAr }))} subjects={subjects.map((s) => ({ id: s.id, label: s.nameAr }))} />
      <div className="card"><h3>التعيينات الحالية</h3>
        {assigns.length ? assigns.map((a) => <p key={a.id}>{a.teacher.user.fullName} ← {a.class.nameAr} — {a.subject.nameAr}</p>) : <p className="muted">لا توجد تعيينات.</p>}</div>

      <AnnouncementForm allowAll classes={classes.map((c) => ({ id: c.id, label: c.nameAr }))} />
      <div className="card"><a className="btn o" href="/api/reports/grades">تصدير كل الدرجات (CSV / Excel)</a></div>

      <h3>المستخدمون</h3>
      <div className="card tw"><table>
        <thead><tr><th>الاسم</th><th>البريد</th><th>الدور</th><th>الحالة</th><th></th></tr></thead>
        <tbody>{users.map((u) => (
          <tr key={u.id}><td>{u.fullName}{u.isDemo ? " (تجريبي)" : ""}</td><td dir="ltr">{u.email}</td><td>{ROLE[u.role]}</td>
            <td>{u.isActive ? "نشط" : "معطّل"}</td>
            <td>{u.id !== user.id && <ToggleActive userId={u.id} isActive={u.isActive} />}</td></tr>
        ))}</tbody></table></div>

      <h3>سجل التدقيق</h3>
      <div className="card tw">{logs.length === 0 ? <span className="muted">لا توجد إجراءات بعد.</span> : (
        <table><thead><tr><th>الوقت</th><th>المنفّذ</th><th>الإجراء</th><th>الكيان</th></tr></thead>
          <tbody>{logs.map((l) => (
            <tr key={l.id}><td>{l.createdAt.toLocaleString("ar")}</td><td>{l.actor?.fullName ?? "—"}</td>
              <td>{l.action}</td><td dir="ltr">{l.entityType}:{l.entityId.slice(0, 8)}</td></tr>
          ))}</tbody></table>)}
      </div>
    </Shell>
  );
}
