// إعداد تلقائي: npm run setup
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, readdirSync, appendFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import readline from "node:readline/promises";

const run = (cmd, env = {}) => {
  console.log("\n▶", cmd);
  const r = spawnSync(cmd, { stdio: "inherit", shell: true, env: { ...process.env, ...env } });
  if (r.status !== 0) { console.error("\n✗ فشلت الخطوة:", cmd, "\nانسخ رسالة الخطأ أعلاه وأرسلها لمن يساعدك."); process.exit(1); }
};

async function ensureEnv() {
  let env = existsSync(".env") ? readFileSync(".env", "utf8") : readFileSync(".env.example", "utf8");
  const get = (k) => (env.match(new RegExp(`^${k}=\\"?([^\\"\\n]*)`, "m")) ?? [])[1] ?? "";
  if (!/^postgres(ql)?:\/\//.test(get("DATABASE_URL")) || get("DATABASE_URL").includes("USER:PASSWORD")) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const url = (await rl.question("\nالصق رابط قاعدة البيانات (Supabase > Connect > Session pooler)، ثم Enter:\n> ")).trim();
    rl.close();
    if (!/^postgres(ql)?:\/\//.test(url)) { console.error("الرابط غير صحيح: يجب أن يبدأ بـ postgresql://"); process.exit(1); }
    env = env.replace(/^DATABASE_URL=.*$/m, `DATABASE_URL="${url}"`);
  }
  if (get("AUTH_SECRET").length < 32) env = env.replace(/^AUTH_SECRET=.*$/m, `AUTH_SECRET="${randomBytes(32).toString("base64")}"`);
  writeFileSync(".env", env); writeFileSync(".env.local", env);
  console.log("✓ تم تجهيز ملفي .env و .env.local");
}

await ensureEnv();
const migs = () => (existsSync("prisma/migrations") ? readdirSync("prisma/migrations") : []);
if (!migs().some((m) => m.endsWith("_init"))) run("npx prisma migrate dev --name init");
if (!migs().some((m) => m.endsWith("_constraints"))) {
  run("npx prisma migrate dev --create-only --name constraints");
  const dir = migs().find((m) => m.endsWith("_constraints"));
  appendFileSync(`prisma/migrations/${dir}/migration.sql`, "\n" + readFileSync("prisma/sql/constraints.sql", "utf8"));
  console.log("✓ أُضيفت قيود قاعدة البيانات");
}
run("npx prisma migrate dev");
run("npm test");
run("npx tsx prisma/seed.ts", { ALLOW_DEMO_SEED: "true" });
console.log("\n✓ تم الإعداد. شغّل الموقع بالأمر: npm run dev");
