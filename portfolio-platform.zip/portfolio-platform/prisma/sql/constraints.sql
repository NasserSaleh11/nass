-- يُطبّق كـ migration مخصّص بعد migration الأساسي:
--   npx prisma migrate dev --create-only --name constraints
-- ثم الصق المحتوى أدناه في ملف migration.sql الناتج.
ALTER TABLE "Assignment" ADD CONSTRAINT assignment_max_grade_positive CHECK ("maxGrade" > 0);
ALTER TABLE "Evaluation" ADD CONSTRAINT evaluation_grade_range CHECK ("grade" >= 0 AND "grade" <= "maxGrade");
ALTER TABLE "SubmissionFile" ADD CONSTRAINT file_size_positive CHECK ("sizeBytes" > 0);
-- نسخة حالية واحدة فقط لكل سلسلة مراجعات يضمنها isCurrent؛ فهرس جزئي لمنع التكرار لنفس (الطالب، الواجب):
CREATE UNIQUE INDEX submission_one_current_per_assignment
  ON "Submission" ("studentId", "assignmentId")
  WHERE "isCurrent" = true AND "assignmentId" IS NOT NULL;
