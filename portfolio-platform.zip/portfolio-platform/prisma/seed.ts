// بيانات تجريبية للتطوير فقط. يرفض العمل في الإنتاج.
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  if (process.env.NODE_ENV === "production" || process.env.ALLOW_DEMO_SEED !== "true") {
    throw new Error("Seeding demo data requires ALLOW_DEMO_SEED=true and a non-production environment.");
  }
  const pw = await bcrypt.hash(process.env.DEMO_PASSWORD ?? "Demo#12345", 12);

  const math = await prisma.subject.upsert({ where: { code: "MATH" }, update: {}, create: { code: "MATH", nameAr: "الرياضيات", nameEn: "Mathematics" } });
  await prisma.subject.upsert({ where: { code: "SCI" }, update: {}, create: { code: "SCI", nameAr: "العلوم", nameEn: "Science" } });

  const classes = [];
  for (const [i, n] of ["الفصل الأول", "الفصل الثاني", "الفصل الثالث"].entries()) {
    classes.push(await prisma.class.upsert({
      where: { nameAr_year: { nameAr: n, year: "2026" } }, update: {},
      create: { nameAr: n, nameEn: `Class ${i + 1}`, year: "2026" } }));
  }

  await prisma.user.upsert({ where: { email: "admin@demo.local" }, update: {},
    create: { email: "admin@demo.local", passwordHash: pw, fullName: "مدير النظام (تجريبي)", role: "ADMIN", isDemo: true } });

  const teacher = await prisma.user.upsert({ where: { email: "teacher@demo.local" }, update: {},
    create: { email: "teacher@demo.local", passwordHash: pw, fullName: "المعلم خالد (تجريبي)", role: "TEACHER", isDemo: true, teacher: { create: {} } },
    include: { teacher: true } });
  const tid = teacher.teacher!.id;

  for (const c of classes) {
    await prisma.teacherClass.upsert({
      where: { teacherId_classId_subjectId: { teacherId: tid, classId: c.id, subjectId: math.id } },
      update: {}, create: { teacherId: tid, classId: c.id, subjectId: math.id } });
  }

  const demoStudents = [
    { email: "ahmed@demo.local", name: "أحمد محمد (تجريبي)", no: "DEMO-001", cls: classes[0] },
    { email: "sara@demo.local", name: "سارة علي (تجريبي)", no: "DEMO-002", cls: classes[1] },
  ];
  for (const s of demoStudents) {
    const u = await prisma.user.upsert({ where: { email: s.email }, update: {},
      create: { email: s.email, passwordHash: pw, fullName: s.name, role: "STUDENT", isDemo: true, student: { create: { studentNo: s.no } } },
      include: { student: true } });
    await prisma.enrollment.upsert({
      where: { studentId_classId: { studentId: u.student!.id, classId: s.cls.id } },
      update: {}, create: { studentId: u.student!.id, classId: s.cls.id } });
  }

  if (!(await prisma.assignment.findFirst({ where: { title: "ورقة عمل رياضيات 01" } }))) {
    await prisma.assignment.create({ data: { title: "ورقة عمل رياضيات 01", classId: classes[0].id, subjectId: math.id,
      teacherId: tid, maxGrade: 20, deadline: new Date(Date.now() + 7 * 864e5) } });
  }
  console.log("Demo data ready: admin@demo.local / teacher@demo.local / ahmed@demo.local / sara@demo.local");
}
main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
