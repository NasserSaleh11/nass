/* eslint-disable @typescript-eslint/no-explicit-any */
// قاعدة بيانات وهمية في الذاكرة لاختبار منطق الصلاحيات بدون PostgreSQL.
// يجب استيراد هذا الملف قبل أي ملف يستورد src/lib/prisma.
export const data = {
  studentProfiles: [{ id: "pa", userId: "ua" }, { id: "pb", userId: "ub" }, { id: "pc", userId: "uc" }],
  teacherProfiles: [{ id: "tp1", userId: "ut1" }, { id: "tp2", userId: "ut2" }],
  teacherClasses: [{ teacherId: "tp1", classId: "c1" }, { teacherId: "tp2", classId: "c2" }],
  enrollments: [{ studentId: "pa", classId: "c1" }, { studentId: "pb", classId: "c1" }, { studentId: "pc", classId: "c2" }],
  submissions: [
    { id: "s1", studentId: "pa", status: "PENDING", isCurrent: true, assignment: null },
    { id: "s2", studentId: "pb", status: "EVALUATED", isCurrent: true, assignment: null },
    { id: "s3", studentId: "pc", status: "PENDING", isCurrent: true, assignment: null },
    { id: "s4", studentId: "pa", status: "RESUBMIT_REQUESTED", isCurrent: true, assignment: { classId: "c1", allowResubmit: false } },
    { id: "s5", studentId: "pa", status: "PENDING", isCurrent: true, assignment: { classId: "c1", allowResubmit: false } },
    { id: "s6", studentId: "pa", status: "PENDING", isCurrent: false, assignment: null },
  ] as any[],
  files: [{ id: "f1", submissionId: "s1" }, { id: "f3", submissionId: "s3" }],
};

const prisma = {
  teacherProfile: { findUnique: async ({ where }: any) => data.teacherProfiles.find((x) => x.userId === where.userId) ?? null },
  studentProfile: { findUnique: async ({ where }: any) => data.studentProfiles.find((x) => x.userId === where.userId) ?? null },
  teacherClass: { findFirst: async ({ where }: any) =>
    data.teacherClasses.find((x) => x.teacherId === where.teacherId && x.classId === where.classId) ?? null },
  submission: { findUnique: async ({ where }: any) => data.submissions.find((x) => x.id === where.id) ?? null },
  submissionFile: { findUnique: async ({ where }: any) => data.files.find((x) => x.id === where.id) ?? null },
  enrollment: { findFirst: async ({ where }: any) => {
    const tid = where.class.teacherClasses.some.teacherId;
    return data.enrollments.find((e) => e.studentId === where.studentId &&
      data.teacherClasses.some((t) => t.classId === e.classId && t.teacherId === tid)) ?? null;
  } },
};

// eslint-disable-next-line @typescript-eslint/no-require-imports
const p = require.resolve("../src/lib/prisma");
require.cache[p] = { id: p, filename: p, loaded: true, exports: { prisma }, children: [], paths: [] } as any;
