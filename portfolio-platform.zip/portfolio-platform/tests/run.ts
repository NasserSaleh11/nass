/* eslint-disable @typescript-eslint/no-explicit-any */
import "./mock-prisma";
import assert from "node:assert/strict";
import { canViewSubmission, canGrade, canDownloadFile, canResubmit, commentVisibilityFilter, requireRole, ForbiddenError } from "../src/lib/authz";
import { checkFile, cleanName } from "../src/lib/files";
import { csvCell, toCsv } from "../src/lib/csv";

const U = (id: string, role: any, isActive = true) => ({ id, role, isActive });
const studentA = U("ua", "STUDENT"), studentB = U("ub", "STUDENT"), studentC = U("uc", "STUDENT");
const t1 = U("ut1", "TEACHER"), t2 = U("ut2", "TEACHER"), admin = U("uadm", "ADMIN");

let passed = 0, failed = 0;
async function test(name: string, fn: () => Promise<void> | void) {
  try { await fn(); passed++; console.log("  ✓", name); }
  catch (e) { failed++; console.log("  ✗", name, "\n     ", (e as Error).message); }
}

(async () => {
  console.log("الصلاحيات (authz)");
  await test("الطالب يرى تسليمه فقط", async () => {
    assert.equal(await canViewSubmission(studentA, "s1"), true);
    assert.equal(await canViewSubmission(studentA, "s2"), false);
    assert.equal(await canViewSubmission(studentB, "s1"), false);
  });
  await test("المعلم يرى طلاب فصوله فقط", async () => {
    assert.equal(await canViewSubmission(t1, "s1"), true);
    assert.equal(await canViewSubmission(t1, "s2"), true);
    assert.equal(await canViewSubmission(t1, "s3"), false);
    assert.equal(await canViewSubmission(t2, "s3"), true);
    assert.equal(await canViewSubmission(t2, "s1"), false);
  });
  await test("المدير يرى كل شيء", async () => { assert.equal(await canViewSubmission(admin, "s3"), true); });
  await test("تسليم غير موجود يُرفض", async () => { assert.equal(await canViewSubmission(t1, "nope"), false); });
  await test("الطالب لا يستطيع التقييم", async () => {
    assert.equal(await canGrade(studentA, "s1"), false);
    assert.equal(await canGrade(studentC, "s3"), false);
  });
  await test("المعلم يقيّم طلاب فصوله فقط", async () => {
    assert.equal(await canGrade(t1, "s1"), true);
    assert.equal(await canGrade(t2, "s1"), false);
  });
  await test("الحساب المعطّل يُمنع", async () => {
    await assert.rejects(() => canViewSubmission(U("ua", "STUDENT", false), "s1"), ForbiddenError);
    await assert.rejects(() => canGrade(U("ut1", "TEACHER", false), "s1"), ForbiddenError);
  });
  await test("تنزيل الملفات يتبع صلاحية التسليم", async () => {
    assert.equal(await canDownloadFile(studentA, "f1"), true);
    assert.equal(await canDownloadFile(studentB, "f1"), false);
    assert.equal(await canDownloadFile(t1, "f1"), true);
    assert.equal(await canDownloadFile(t1, "f3"), false);
    assert.equal(await canDownloadFile(studentA, "missing"), false);
  });
  await test("إعادة التسليم: فقط عند الطلب أو قبل التقييم", async () => {
    assert.equal(await canResubmit(studentA, "s4"), true);   // طُلبت إعادة التسليم
    assert.equal(await canResubmit(studentA, "s5"), false);  // واجب لا يسمح بالاستبدال
    assert.equal(await canResubmit(studentA, "s1"), true);   // رفع حر قيد الانتظار
    assert.equal(await canResubmit(studentB, "s2"), false);  // مُقيَّم
    assert.equal(await canResubmit(studentB, "s1"), false);  // ليس تسليمه
    assert.equal(await canResubmit(studentA, "s6"), false);  // نسخة قديمة
    assert.equal(await canResubmit(t1, "s1"), false);        // معلم
  });
  await test("الملاحظات الداخلية مخفية عن الطالب فقط", () => {
    assert.deepEqual(commentVisibilityFilter(studentA), { internal: false });
    assert.deepEqual(commentVisibilityFilter(t1), {});
  });
  await test("requireRole", () => {
    assert.throws(() => requireRole(studentA, "TEACHER", "ADMIN"), ForbiddenError);
    assert.doesNotThrow(() => requireRole(t1, "TEACHER"));
  });

  console.log("فحص الملفات (files)");
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]);
  const pdf = Buffer.from("%PDF-1.4\n...");
  const zip = Buffer.from([0x50, 0x4b, 0x03, 0x04, 0, 0, 0, 0]);
  const ole = Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1, 0]);
  const jpg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0]);
  await test("أنواع صحيحة تُقبل", () => {
    assert.equal(checkFile("a.png", png).mime, "image/png");
    assert.equal(checkFile("A.PDF", pdf).ext, "pdf");
    assert.equal(checkFile("w.docx", zip).ext, "docx");
    assert.equal(checkFile("p.pptx", zip).ext, "pptx");
    assert.equal(checkFile("o.doc", ole).ext, "doc");
    assert.equal(checkFile("o.ppt", ole).ext, "ppt");
    assert.equal(checkFile("x.jpeg", jpg).ext, "jpeg");
  });
  await test("امتداد غير مسموح يُرفض", () => {
    assert.throws(() => checkFile("virus.exe", Buffer.from("MZ....")), /غير مسموح/);
    assert.throws(() => checkFile("page.html", Buffer.from("<html>")), /غير مسموح/);
    assert.throws(() => checkFile("noext", pdf), /غير مسموح/);
  });
  await test("محتوى لا يطابق الامتداد يُرفض", () => {
    assert.throws(() => checkFile("fake.png", pdf), /لا يطابق/);
    assert.throws(() => checkFile("fake.pdf", Buffer.from("<script>alert(1)</script>")), /لا يطابق/);
    assert.throws(() => checkFile("fake.docx", png), /لا يطابق/);
  });
  await test("ملف فارغ يُرفض", () => { assert.throws(() => checkFile("a.pdf", Buffer.alloc(0)), /فارغ/); });
  await test("تنظيف اسم الملف", () => {
    assert.equal(cleanName("../../etc/passwd"), "passwd");
    assert.equal(cleanName("a<b>c.pdf"), "a_b_c.pdf");
    assert.equal(cleanName("x".repeat(300)).length, 150);
  });

  console.log("تصدير CSV");
  await test("منع حقن الصيغ وتهريب الفواصل", () => {
    assert.equal(csvCell("=HYPERLINK(\"x\")"), "\"'=HYPERLINK(\"\"x\"\")\"");
    assert.equal(csvCell("+1"), "'+1");
    assert.equal(csvCell("@cmd"), "'@cmd");
    assert.equal(csvCell("a,b"), "\"a,b\"");
    assert.equal(csvCell("أحمد"), "أحمد");
    assert.equal(csvCell(17), "17");
    assert.equal(csvCell(null), "");
  });
  await test("ملف CSV يبدأ بـ BOM", () => {
    const s = toCsv([["a", "b"], [1, 2]]);
    assert.equal(s.charCodeAt(0), 0xfeff);
    assert.equal(s.slice(1), "a,b\r\n1,2");
  });

  console.log(`\nالنتيجة: ${passed} نجح، ${failed} فشل`);
  process.exit(failed ? 1 : 0);
})();
